# Módulo Core del Sistema de Construcción
# Este módulo contiene todos los modelos, vistas, formularios y servicios principales

default_app_config = 'core.apps.CoreConfig'
